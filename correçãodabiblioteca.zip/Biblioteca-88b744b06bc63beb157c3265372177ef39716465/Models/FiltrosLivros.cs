namespace Biblioteca.Models
{
    public class FiltrosLivros
    {
        public string TipoFiltro {get; set;}
        public string Filtro {get; set;}
    }
}