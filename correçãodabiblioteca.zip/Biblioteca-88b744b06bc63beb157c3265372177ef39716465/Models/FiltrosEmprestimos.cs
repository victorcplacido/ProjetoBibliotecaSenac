using System;

namespace Biblioteca.Models
{
    public class FiltrosEmprestimos
    {
        public string TipoFiltro {get; set;}
        public string Filtro {get; set;}
    }
}